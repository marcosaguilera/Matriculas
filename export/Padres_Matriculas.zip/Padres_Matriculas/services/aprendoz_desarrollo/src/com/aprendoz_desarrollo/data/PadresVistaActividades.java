
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaActividades
 *  06/12/2013 12:22:58
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividades() {
    }

    public PadresVistaActividades(PadresVistaActividadesId id) {
        this.id = id;
    }

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
