
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEventualidadesNotificaciones
 *  06/12/2013 12:22:59
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificaciones() {
    }

    public VistaEventualidadesNotificaciones(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}
