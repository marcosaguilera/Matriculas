
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "personaGetInfo" on 01/13/2014 10:25:20
 * 
 */
public class PersonaGetInfoRtnType {

    private String tipoDocumento;
    private String numeroDocumento;
    private String n1;
    private String n2;
    private String a1;
    private String a2;
    private String usuario;
    private String clave1;
    private String correo;
    private String sexo1;
    private String tipoPe;
    private Integer tipoId;
    private Integer idFamilia;
    private String grupoFamilia;
    private Integer idpersona;
    private String documento;

    public PersonaGetInfoRtnType() {
    }

    public PersonaGetInfoRtnType(String tipoDocumento, String numeroDocumento, String n1, String n2, String a1, String a2, String usuario, String clave1, String correo, String sexo1, String tipoPe, Integer tipoId, Integer idFamilia, String grupoFamilia, Integer idpersona, String documento) {
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.n1 = n1;
        this.n2 = n2;
        this.a1 = a1;
        this.a2 = a2;
        this.usuario = usuario;
        this.clave1 = clave1;
        this.correo = correo;
        this.sexo1 = sexo1;
        this.tipoPe = tipoPe;
        this.tipoId = tipoId;
        this.idFamilia = idFamilia;
        this.grupoFamilia = grupoFamilia;
        this.idpersona = idpersona;
        this.documento = documento;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getN1() {
        return n1;
    }

    public void setN1(String n1) {
        this.n1 = n1;
    }

    public String getN2() {
        return n2;
    }

    public void setN2(String n2) {
        this.n2 = n2;
    }

    public String getA1() {
        return a1;
    }

    public void setA1(String a1) {
        this.a1 = a1;
    }

    public String getA2() {
        return a2;
    }

    public void setA2(String a2) {
        this.a2 = a2;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getClave1() {
        return clave1;
    }

    public void setClave1(String clave1) {
        this.clave1 = clave1;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getSexo1() {
        return sexo1;
    }

    public void setSexo1(String sexo1) {
        this.sexo1 = sexo1;
    }

    public String getTipoPe() {
        return tipoPe;
    }

    public void setTipoPe(String tipoPe) {
        this.tipoPe = tipoPe;
    }

    public Integer getTipoId() {
        return tipoId;
    }

    public void setTipoId(Integer tipoId) {
        this.tipoId = tipoId;
    }

    public Integer getIdFamilia() {
        return idFamilia;
    }

    public void setIdFamilia(Integer idFamilia) {
        this.idFamilia = idFamilia;
    }

    public String getGrupoFamilia() {
        return grupoFamilia;
    }

    public void setGrupoFamilia(String grupoFamilia) {
        this.grupoFamilia = grupoFamilia;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

}
