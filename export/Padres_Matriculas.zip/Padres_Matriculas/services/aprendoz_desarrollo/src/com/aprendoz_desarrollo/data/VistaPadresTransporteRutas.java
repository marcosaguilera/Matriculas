
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPadresTransporteRutas
 *  06/12/2013 12:22:59
 * 
 */
public class VistaPadresTransporteRutas {

    private VistaPadresTransporteRutasId id;

    public VistaPadresTransporteRutas() {
    }

    public VistaPadresTransporteRutas(VistaPadresTransporteRutasId id) {
        this.id = id;
    }

    public VistaPadresTransporteRutasId getId() {
        return id;
    }

    public void setId(VistaPadresTransporteRutasId id) {
        this.id = id;
    }

}
