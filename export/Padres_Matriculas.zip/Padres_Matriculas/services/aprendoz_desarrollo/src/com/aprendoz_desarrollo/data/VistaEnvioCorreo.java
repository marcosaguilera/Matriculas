
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEnvioCorreo
 *  06/12/2013 12:22:58
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreo() {
    }

    public VistaEnvioCorreo(VistaEnvioCorreoId id) {
        this.id = id;
    }

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
