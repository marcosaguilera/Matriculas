
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscripcionesVistaInscAlumnCurso
 *  06/12/2013 12:22:58
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCurso() {
    }

    public InscripcionesVistaInscAlumnCurso(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
