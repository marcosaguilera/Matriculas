
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprEsperados
 *  06/12/2013 12:22:58
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperados() {
    }

    public AprEsperados(AprEsperadosId id) {
        this.id = id;
    }

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
