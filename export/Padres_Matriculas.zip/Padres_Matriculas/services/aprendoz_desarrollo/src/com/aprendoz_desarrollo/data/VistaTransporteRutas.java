
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaTransporteRutas
 *  09/19/2012 14:22:31
 * 
 */
public class VistaTransporteRutas {

    private VistaTransporteRutasId id;

    public VistaTransporteRutas() {
    }

    public VistaTransporteRutas(VistaTransporteRutasId id) {
        this.id = id;
    }

    public VistaTransporteRutasId getId() {
        return id;
    }

    public void setId(VistaTransporteRutasId id) {
        this.id = id;
    }

}
