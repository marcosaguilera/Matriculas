
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprFechaLogrado
 *  10/08/2011 12:59:25
 * 
 */
public class AprFechaLogrado {

    private AprFechaLogradoId id;

    public AprFechaLogrado() {
    }

    public AprFechaLogrado(AprFechaLogradoId id) {
        this.id = id;
    }

    public AprFechaLogradoId getId() {
        return id;
    }

    public void setId(AprFechaLogradoId id) {
        this.id = id;
    }

}
