
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "returExitsValue" on 01/13/2014 10:25:20
 * 
 */
public class ReturExitsValueRtnType {

    private Long retorno;

    public ReturExitsValueRtnType() {
    }

    public ReturExitsValueRtnType(Long retorno) {
        this.retorno = retorno;
    }

    public Long getRetorno() {
        return retorno;
    }

    public void setRetorno(Long retorno) {
        this.retorno = retorno;
    }

}
