
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_getAnuncio" on 01/13/2014 10:25:20
 * 
 */
public class _getAnuncioRtnType {

    private String anuncio;

    public _getAnuncioRtnType() {
    }

    public _getAnuncioRtnType(String anuncio) {
        this.anuncio = anuncio;
    }

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
