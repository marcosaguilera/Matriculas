
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "maxSy" on 01/13/2014 10:25:20
 * 
 */
public class MaxSyRtnType {

    private Integer idsy;

    public MaxSyRtnType() {
    }

    public MaxSyRtnType(Integer idsy) {
        this.idsy = idsy;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

}
