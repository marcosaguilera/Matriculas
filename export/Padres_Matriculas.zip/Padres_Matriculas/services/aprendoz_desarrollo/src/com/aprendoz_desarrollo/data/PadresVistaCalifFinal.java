
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaCalifFinal
 *  06/12/2013 12:22:58
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinal() {
    }

    public PadresVistaCalifFinal(PadresVistaCalifFinalId id) {
        this.id = id;
    }

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
