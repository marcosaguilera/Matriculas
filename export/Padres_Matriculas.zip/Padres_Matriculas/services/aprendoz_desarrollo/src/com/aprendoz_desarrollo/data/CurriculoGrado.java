
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CurriculoGrado
 *  06/12/2013 12:22:58
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGrado() {
    }

    public CurriculoGrado(CurriculoGradoId id) {
        this.id = id;
    }

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
