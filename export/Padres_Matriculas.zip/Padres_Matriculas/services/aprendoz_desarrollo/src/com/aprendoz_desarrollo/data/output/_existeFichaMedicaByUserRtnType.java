
package com.aprendoz_desarrollo.data.output;



/**
 * Generated for query "_existeFichaMedicaByUser" on 01/13/2014 10:25:20
 * 
 */
public class _existeFichaMedicaByUserRtnType {

    private Integer idpersona;

    public _existeFichaMedicaByUserRtnType() {
    }

    public _existeFichaMedicaByUserRtnType(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

}
