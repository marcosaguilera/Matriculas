
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.InscipcionesVistaAsignaturas
 *  06/12/2013 12:22:58
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturas() {
    }

    public InscipcionesVistaAsignaturas(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
