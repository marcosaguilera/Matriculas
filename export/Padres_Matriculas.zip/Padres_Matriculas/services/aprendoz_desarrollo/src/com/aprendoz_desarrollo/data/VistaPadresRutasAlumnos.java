
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPadresRutasAlumnos
 *  06/12/2013 12:22:58
 * 
 */
public class VistaPadresRutasAlumnos {

    private VistaPadresRutasAlumnosId id;

    public VistaPadresRutasAlumnos() {
    }

    public VistaPadresRutasAlumnos(VistaPadresRutasAlumnosId id) {
        this.id = id;
    }

    public VistaPadresRutasAlumnosId getId() {
        return id;
    }

    public void setId(VistaPadresRutasAlumnosId id) {
        this.id = id;
    }

}
