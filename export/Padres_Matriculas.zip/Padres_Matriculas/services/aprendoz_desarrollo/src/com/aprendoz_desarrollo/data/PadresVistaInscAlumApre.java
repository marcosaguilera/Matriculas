
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaInscAlumApre
 *  04/12/2012 16:51:12
 * 
 */
public class PadresVistaInscAlumApre {

    private PadresVistaInscAlumApreId id;

    public PadresVistaInscAlumApre() {
    }

    public PadresVistaInscAlumApre(PadresVistaInscAlumApreId id) {
        this.id = id;
    }

    public PadresVistaInscAlumApreId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumApreId id) {
        this.id = id;
    }

}
