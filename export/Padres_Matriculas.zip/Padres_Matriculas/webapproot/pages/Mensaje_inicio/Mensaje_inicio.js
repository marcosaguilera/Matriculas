dojo.declare("Mensaje_inicio", wm.Page, {
	start: function() {
		
	},
	_end: 0
});