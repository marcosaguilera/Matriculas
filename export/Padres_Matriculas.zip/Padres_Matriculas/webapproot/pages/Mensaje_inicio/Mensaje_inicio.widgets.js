Mensaje_inicio.widgets = {
	layoutBox1: ["wm.Layout", {"height":"100%","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		instructivo: ["wm.IFrame", {"height":"100%","width":"100%","border":"0","source":"http://aprendoz.rochester.edu.co/recursos/iniciomatriculas/iniciomatriculas.html"}, {}]
	}]
}